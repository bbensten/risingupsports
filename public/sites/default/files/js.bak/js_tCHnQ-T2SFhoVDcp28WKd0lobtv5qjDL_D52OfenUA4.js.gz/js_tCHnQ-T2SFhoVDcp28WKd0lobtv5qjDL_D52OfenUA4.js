(function($) {

//Mega dropdown functionality
$('#zone-branding-wrapper .block-mega-table .panel-col-top a').live('mouseenter', function () {
  $('#zone-branding-wrapper .block-mega-table .center-wrapper').slideDown('fast');
});

$('#zone-branding-wrapper .block-mega-table').live('mouseleave', function () {
  $('#zone-branding-wrapper .block-mega-table .center-wrapper').slideUp('fast');
});

//Crew dropdown functionality
$('#mini-panel-crew_dropdown').live('mouseenter', function () {
  $('#mini-panel-crew_dropdown .pane-views-panes').slideDown('fast');
});

$('#mini-panel-crew_dropdown').live('mouseleave', function () {
  $('#mini-panel-crew_dropdown .pane-views-panes').slideUp('fast');
});

////More videos dropdown functionality.
//$('.views-grid-full-more').live('mouseenter', function () {
//  $(this).children('.views-grid-full-more-menu').slideDown('fast');
//});
//
//$('.views-grid-full-more').live('mouseleave', function () {
//  $(this).children('.views-grid-full-more-menu').slideUp('fast');
//});

$('.kaltura-embed').live('mousedown', function(){
  $('.field-name-video-stripe').fadeOut('slow');
});




})(jQuery);;
